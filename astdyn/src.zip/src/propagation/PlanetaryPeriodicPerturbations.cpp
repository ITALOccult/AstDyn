#include "astdyn/propagation/PlanetaryPeriodicPerturbations.hpp"
#include "astdyn/core/Constants.hpp"
#include <cmath>
#include <iostream>
#include <algorithm>
#include <iterator>

namespace astdyn::propagation {

using namespace astdyn::constants;

namespace {
    constexpr double T0_LONGSTOP = 2440400.5;
    constexpr double AS_YR_TO_RAD_DAY = (PI / (180.0 * 3600.0)) / 365.25;
    constexpr double DEG_TO_RAD = PI / 180.0;

    const double G_PLANET[9] = {0, 0, 0, 0, 0, 4.245016 * AS_YR_TO_RAD_DAY, 28.237937 * AS_YR_TO_RAD_DAY, 3.087924 * AS_YR_TO_RAD_DAY, 0.672952 * AS_YR_TO_RAD_DAY};
    const double FAG_PLANET[9] = {0, 0, 0, 0, 0, 27.0005 * DEG_TO_RAD, 124.1994 * DEG_TO_RAD, 117.0516 * DEG_TO_RAD, 70.7508 * DEG_TO_RAD};
    const double A_PLANET[9] = {0, 0.387098, 0.723332, 1.000000, 1.523662, 5.20259867695, 9.55493438259, 19.2184342840, 30.1104468747};
    const double E_PLANET[9] = {0, 0.2056, 0.00677, 0.0167, 0.0934, 0.04839, 0.05415, 0.04717, 0.00859};
    const double I_PLANET[9] = {0, 7.005*DEG_TO_RAD, 3.395*DEG_TO_RAD, 0.0, 1.85*DEG_TO_RAD, 1.305*DEG_TO_RAD, 2.484*DEG_TO_RAD, 0.77*DEG_TO_RAD, 1.77*DEG_TO_RAD};

    inline double normalize(double x) {
        x = std::fmod(x, TWO_PI);
        if (x < 0) x += TWO_PI;
        return x;
    }

    static const DirectHamTerm DIRECT_TERMS[197] = {
{1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0}, {1,1,1,1,2,0,0,0,0,2,2,0,0,0,0,0,0}, {1,4,2,0,0,2,0,0,0,0,0,0,0,0,0,0,0},
{1,4,3,0,0,0,2,0,0,0,0,0,0,0,0,0,0}, {1,16,4,0,0,4,0,0,0,0,0,0,0,0,0,0,0}, {1,16,5,0,0,2,2,0,0,0,0,0,0,0,0,0,0},
{1,16,6,0,0,0,4,0,0,0,0,0,0,0,0,0,0}, {1,4,11,0,0,0,0,2,0,0,0,0,0,0,0,0,0}, {1,4,11,0,0,0,0,0,2,0,0,0,0,0,0,0,0},
{1,16,11,0,0,0,0,4,0,0,0,0,0,0,0,0,0}, {1,16,11,0,0,0,0,0,4,0,0,0,0,0,0,0,0}, {1,8,11,1,0,0,0,2,2,0,0,0,0,0,0,0,0},
{1,16,12,0,0,2,0,2,0,0,0,0,0,0,0,0,0}, {1,16,12,0,0,2,0,0,2,0,0,0,0,0,0,0,0}, {1,16,13,0,0,0,2,2,0,0,0,0,0,0,0,0,0},
{1,16,13,0,0,0,2,0,2,0,0,0,0,0,0,0,0}, {1,16,17,0,0,0,0,4,0,0,0,0,0,0,0,0,0}, {1,16,17,0,0,0,0,0,4,0,0,0,0,0,0,0,0},
{1,4,17,0,0,0,0,2,2,0,0,0,0,0,0,0,0}, {1,1,1,0,1,0,0,0,0,1,1,0,0,0,0,-1,1}, {1,2,1,0,1,0,0,0,0,3,1,0,0,0,0,-1,1},
{1,2,1,0,1,0,0,0,0,1,3,0,0,0,0,-1,1}, {1,4,2,0,1,2,0,0,0,1,1,0,0,0,0,-1,1}, {1,4,3,0,1,0,2,0,0,1,1,0,0,0,0,-1,1},
{1,4,11,0,1,0,0,2,0,1,1,0,0,0,0,-1,1}, {1,4,11,0,1,0,0,0,2,1,1,0,0,0,0,-1,1}, {1,4,11,1,0,0,0,1,1,0,0,0,0,0,0,-1,1},
{1,16,12,1,0,2,0,1,1,0,0,0,0,0,0,-1,1}, {1,16,13,1,0,0,2,1,1,0,0,0,0,0,0,-1,1}, {1,8,17,1,0,0,0,3,1,0,0,0,0,0,0,-1,1},
{1,8,17,1,0,0,0,1,3,0,0,0,0,0,0,-1,1}, {1,1,1,1,1,0,0,0,0,1,1,0,0,0,0,1,-1}, {1,2,1,1,1,0,0,0,0,3,1,0,0,0,0,1,-1},
{1,2,1,1,1,0,0,0,0,1,3,0,0,0,0,1,-1}, {1,4,2,1,1,2,0,0,0,1,1,0,0,0,0,1,-1}, {1,4,3,1,1,0,2,0,0,1,1,0,0,0,0,1,-1},
{1,4,11,1,1,0,0,2,0,1,1,0,0,0,0,1,-1}, {1,4,11,1,1,0,0,0,2,1,1,0,0,0,0,1,-1}, {1,4,11,1,0,0,0,1,1,0,0,0,0,0,0,1,-1},
{1,16,12,1,0,2,0,1,1,0,0,0,0,0,0,1,-1}, {1,16,13,1,0,0,2,1,1,0,0,0,0,0,0,1,-1}, {1,8,17,1,0,0,0,3,1,0,0,0,0,0,0,1,-1},
{1,8,17,1,0,0,0,1,3,0,0,0,0,0,0,1,-1}, {1,2,1,0,2,0,0,0,0,2,2,0,0,0,0,-2,2}, {1,2,1,1,1,0,0,0,0,2,2,0,0,0,0,-2,2},
{1,16,11,1,1,0,0,2,2,0,0,0,0,0,0,-2,2}, {1,16,17,0,0,0,0,2,2,0,0,0,0,0,0,-2,2}, {1,2,1,0,2,0,0,0,0,2,2,0,0,0,0,2,-2},
{1,2,1,0,1,0,0,0,0,2,2,0,0,0,0,2,-2}, {1,16,11,0,1,0,0,2,2,0,0,0,0,0,0,2,-2}, {1,16,17,0,0,0,0,2,2,0,0,0,0,0,0,2,-2},
{1,4,21,0,0,1,1,0,0,0,0,1,1,-1,1,0,0}, {1,16,22,0,0,3,1,0,0,0,0,1,1,-1,1,0,0}, {1,16,23,0,0,1,3,0,0,0,0,1,1,-1,1,0,0},
{1,16,27,0,0,1,1,2,0,0,0,1,1,-1,1,0,0}, {1,16,27,0,0,1,1,0,2,0,0,1,1,-1,1,0,0}, {1,4,21,0,1,1,1,0,0,1,1,1,1,-1,1,-1,1},
{1,16,27,1,0,1,1,1,1,0,0,1,1,-1,1,-1,1}, {1,4,21,1,1,1,1,0,0,1,1,1,1,-1,1,1,-1}, {1,16,27,1,0,1,1,1,1,0,0,1,1,-1,1,1,-1},
{1,16,31,0,0,2,2,0,0,0,0,2,2,-2,2,0,0}, {1,16,36,0,0,2,0,2,0,0,0,0,0,0,2,0,-2}, {1,16,36,0,0,2,0,0,2,0,0,0,0,0,2,-2,0},
{1,8,36,1,0,2,0,1,1,0,0,0,0,0,2,-1,-1}, {1,16,40,0,0,1,1,2,0,0,0,-1,-1,1,1,0,-2}, {1,16,40,0,0,1,1,0,2,0,0,-1,-1,1,1,-2,0},
{1,8,40,1,0,1,1,1,1,0,0,-1,-1,1,1,-1,-1}, {1,16,44,0,0,0,2,2,0,0,0,-2,-2,2,0,0,-2}, {1,16,44,0,0,0,2,0,2,0,0,-2,-2,2,0,-2,0},
{1,8,44,1,0,0,2,1,1,0,0,-2,-2,2,0,-1,-1}, {1,2,50,0,0,1,0,0,0,0,0,0,-1,0,-1,0,0}, {1,8,51,0,0,3,0,0,0,0,0,0,-1,0,-1,0,0},
{1,8,52,0,0,1,2,0,0,0,0,0,-1,0,-1,0,0}, {1,8,60,0,0,1,0,2,0,0,0,0,-1,0,-1,0,0}, {1,8,60,0,0,1,0,0,2,0,0,0,-1,0,-1,0,0},
{1,2,50,0,1,1,0,0,0,1,1,0,-1,0,-1,-1,1}, {1,8,60,1,0,1,0,1,1,0,0,0,-1,0,-1,-1,1}, {1,2,50,1,1,1,0,0,0,1,1,0,-1,0,-1,1,-1},
{1,8,60,1,0,1,0,1,1,0,0,0,-1,0,-1,1,-1}, {1,2,70,0,0,0,1,0,0,0,0,1,0,-1,0,0,0}, {1,8,71,0,0,2,1,0,0,0,0,1,0,-1,0,0,0},
{1,8,72,0,0,0,3,0,0,0,0,1,0,-1,0,0,0}, {1,8,80,0,0,0,1,2,0,0,0,1,0,-1,0,0,0}, {1,8,80,0,0,0,1,0,2,0,0,1,0,-1,0,0,0},
{1,2,70,0,1,0,1,0,0,1,1,1,0,-1,0,-1,1}, {1,8,80,1,0,0,1,1,1,0,0,1,0,-1,0,-1,1}, {1,2,70,1,1,0,1,0,0,1,1,1,0,-1,0,1,-1},
{1,8,80,1,0,0,1,1,1,0,0,1,0,-1,0,1,-1}, {1,8,90,0,0,2,1,0,0,0,0,1,2,-1,2,0,0}, {1,8,100,0,0,1,2,0,0,0,0,2,1,-2,1,0,0},
{1,8,120,0,0,1,0,2,0,0,0,0,-1,0,1,0,-2}, {1,8,120,0,0,1,0,0,2,0,0,0,-1,0,1,-2,0}, {1,4,120,1,0,1,0,1,1,0,0,0,-1,0,1,-1,-1},
{1,8,130,0,0,0,1,2,0,0,0,-1,-2,1,0,0,-2}, {1,8,130,0,0,0,1,0,2,0,0,-1,-2,1,0,-2,0}, {1,4,130,1,0,0,1,1,1,0,0,-1,-2,1,0,-1,-1},
{1,4,172,0,0,2,0,0,0,0,0,0,-2,0,-2,0,0}, {1,16,173,0,0,4,0,0,0,0,0,0,-2,0,-2,0,0}, {1,16,174,0,0,2,2,0,0,0,0,0,-2,0,-2,0,0},
{1,16,178,0,0,2,0,2,0,0,0,0,-2,0,-2,0,0}, {1,16,178,0,0,2,0,0,2,0,0,0,-2,0,-2,0,0}, {1,4,172,0,1,2,0,0,0,1,1,0,-2,0,-2,-1,1},
{1,16,178,1,0,2,0,1,1,0,0,0,-2,0,-2,-1,1}, {1,4,172,1,1,2,0,0,0,1,1,0,-2,0,-2,1,-1}, {1,16,178,1,0,2,0,1,1,0,0,0,-2,0,-2,1,-1},
{1,4,182,0,0,1,1,0,0,0,0,1,-1,-1,-1,0,0}, {1,16,183,0,0,3,1,0,0,0,0,1,-1,-1,-1,0,0}, {1,16,184,0,0,1,3,0,0,0,0,1,-1,-1,-1,0,0},
{1,16,188,0,0,1,1,2,0,0,0,1,-1,-1,-1,0,0}, {1,16,188,0,0,1,1,0,2,0,0,1,-1,-1,-1,0,0}, {1,4,182,0,1,1,1,0,0,1,1,1,-1,-1,-1,-1,1},
{1,16,188,1,0,1,1,1,1,0,0,1,-1,-1,-1,-1,1}, {1,4,182,1,1,1,1,0,0,1,1,1,-1,-1,-1,1,-1}, {1,16,188,1,0,1,1,1,1,0,0,1,-1,-1,-1,1,-1},
{1,4,192,0,0,0,2,0,0,0,0,2,0,-2,0,0,0}, {1,16,193,0,0,2,2,0,0,0,0,2,0,-2,0,0,0}, {1,16,194,0,0,0,4,0,0,0,0,2,0,-2,0,0,0},
{1,16,198,0,0,0,2,2,0,0,0,2,0,-2,0,0,0}, {1,16,198,0,0,0,2,0,2,0,0,2,0,-2,0,0,0}, {1,4,192,0,1,0,2,0,0,1,1,2,0,-2,0,-1,1},
{1,16,198,1,0,0,2,1,1,0,0,2,0,-2,0,-1,1}, {1,4,192,1,1,0,2,0,0,1,1,2,0,-2,0,1,-1}, {1,16,198,1,0,0,2,1,1,0,0,2,0,-2,0,1,-1},
{1,16,202,0,0,3,1,0,0,0,0,1,3,-1,3,0,0}, {1,16,206,0,0,1,3,0,0,0,0,3,1,-3,1,0,0}, {1,4,212,0,0,0,0,2,0,0,0,0,-2,0,0,0,-2},
{1,16,212,0,0,0,0,4,0,0,0,0,-2,0,0,0,-2}, {1,16,212,0,0,0,0,2,2,0,0,0,-2,0,0,0,-2}, {1,2,212,0,1,0,0,1,1,1,1,0,-2,0,0,0,-2},
{2,2,212,1,0,0,0,1,1,1,1,0,-2,0,0,0,-2}, {1,16,213,0,0,2,0,2,0,0,0,0,-2,0,0,0,-2}, {1,16,214,0,0,0,2,2,0,0,0,0,-2,0,0,0,-2},
{1,16,218,0,0,0,0,4,0,0,0,0,-2,0,0,0,-2}, {3,16,218,0,0,0,0,2,2,0,0,0,-2,0,0,0,-2}, {1,2,212,1,0,0,0,1,1,0,0,0,-2,0,0,-1,-1},
{1,16,212,0,0,0,0,3,1,0,0,0,-2,0,0,-1,-1}, {1,16,212,1,0,0,0,1,3,0,0,0,-2,0,0,-1,-1}, {1,4,212,0,1,0,0,2,0,1,1,0,-2,0,0,-1,-1},
{2,4,212,1,0,0,0,2,0,1,1,0,-2,0,0,-1,-1}, {1,4,212,1,1,0,0,0,2,1,1,0,-2,0,0,-1,-1}, {2,4,212,0,0,0,0,0,2,1,1,0,-2,0,0,-1,-1},
{1,8,213,1,0,2,0,1,1,0,0,0,-2,0,0,-1,-1}, {1,8,214,1,0,0,2,1,1,0,0,0,-2,0,0,-1,-1}, {3,16,218,1,0,0,0,3,1,0,0,0,-2,0,0,-1,-1},
{3,16,218,1,0,0,0,1,3,0,0,0,-2,0,0,-1,-1}, {1,4,212,0,0,0,0,0,2,0,0,0,-2,0,0,-2,0}, {1,16,212,0,0,0,0,0,4,0,0,0,-2,0,0,-2,0},
{3,16,212,1,0,0,0,2,2,0,0,0,-2,0,0,-2,0}, {1,2,212,1,1,0,0,1,1,1,1,0,-2,0,0,-2,0}, {2,2,212,0,0,0,0,1,1,1,1,0,-2,0,0,-2,0},
{1,16,213,0,0,2,0,0,2,0,0,0,-2,0,0,-2,0}, {1,16,214,0,0,0,2,0,2,0,0,0,-2,0,0,-2,0}, {3,16,218,0,0,0,0,2,2,0,0,0,-2,0,0,-2,0},
{1,16,218,0,0,0,0,0,4,0,0,0,-2,0,0,-2,0}, {1,4,212,1,1,0,0,2,0,1,1,0,-2,0,0,1,-3}, {2,4,212,0,0,0,0,2,0,1,1,0,-2,0,0,1,-3},
{1,16,212,1,0,0,0,3,1,0,0,0,-2,0,0,1,-3}, {1,16,218,1,0,0,0,3,1,0,0,0,-2,0,0,1,-3}, {1,4,212,0,1,0,0,0,2,1,1,0,-2,0,0,-3,1},
{2,4,212,1,0,0,0,0,2,1,1,0,-2,0,0,-3,1}, {1,16,212,0,0,0,0,1,3,0,0,0,-2,0,0,-3,1}, {1,16,218,1,0,0,0,1,3,0,0,0,-2,0,0,-3,1},
{1,16,222,0,0,1,1,2,0,0,0,1,-1,-1,1,0,-2}, {1,16,222,0,0,1,1,0,2,0,0,1,-1,-1,1,-2,0}, {1,8,222,1,0,1,1,1,1,0,0,1,-1,-1,1,-1,-1},
{1,16,226,0,0,1,1,2,0,0,0,-1,-3,1,-1,0,-2}, {1,16,226,0,0,1,1,0,2,0,0,-1,-3,1,-1,-2,0}, {1,8,226,1,0,1,1,1,1,0,0,-1,-3,1,-1,-1,-1},
{1,8,240,0,0,3,0,0,0,0,0,0,-3,0,-3,0,0}, {1,8,250,0,0,2,1,0,0,0,0,1,-2,-1,-2,0,0}, {1,8,260,0,0,1,2,0,0,0,0,2,-1,-2,-1,0,0},
{1,8,270,0,0,0,3,0,0,0,0,3,0,-3,0,0,0}, {1,8,290,0,0,1,0,2,0,0,0,0,-3,0,-1,0,-2}, {1,8,290,0,0,1,0,0,2,0,0,0,-3,0,-1,-2,0},
{1,4,290,1,0,1,0,1,1,0,0,0,-3,0,-1,-1,-1}, {1,8,300,0,0,0,1,2,0,0,0,1,-2,-1,0,0,-2}, {1,8,300,0,0,0,1,0,2,0,0,1,-2,-1,0,-2,0},
{1,4,300,1,0,0,1,1,1,0,0,1,-2,-1,0,-1,-1}, {1,16,336,0,0,4,0,0,0,0,0,0,-4,0,-4,0,0}, {1,16,340,0,0,3,1,0,0,0,0,1,-3,-1,-3,0,0},
{1,16,344,0,0,2,2,0,0,0,0,2,-2,-2,-2,0,0}, {1,16,348,0,0,1,3,0,0,0,0,3,-1,-3,-1,0,0}, {1,16,352,0,0,0,4,0,0,0,0,4,0,-4,0,0,0},
{1,16,358,0,0,2,0,2,0,0,0,0,-4,0,-2,0,-2}, {1,16,358,0,0,2,0,0,2,0,0,0,-4,0,-2,-2,0}, {1,8,358,1,0,2,0,1,1,0,0,0,-4,0,-2,-1,-1},
{1,16,362,0,0,1,1,2,0,0,0,1,-3,-1,-1,0,-2}, {1,16,362,0,0,1,1,0,2,0,0,1,-3,-1,-1,-2,0}, {1,8,362,1,0,1,1,1,1,0,0,1,-3,-1,-1,-1,-1},
{1,16,366,0,0,0,2,2,0,0,0,2,-2,-2,0,0,-2}, {1,16,366,0,0,0,2,0,2,0,0,2,-2,-2,0,-2,0}, {1,8,366,1,0,0,2,1,1,0,0,2,-2,-2,0,-1,-1},
{1,16,372,0,0,0,0,4,0,0,0,0,-4,0,0,0,-4}, {1,4,372,1,0,0,0,3,1,0,0,0,-4,0,0,-1,-3}, {3,8,372,0,0,0,0,2,2,0,0,0,-4,0,0,-2,-2},
{1,4,372,1,0,0,0,1,3,0,0,0,-4,0,0,-3,-1}, {1,16,372,0,0,0,0,0,4,0,0,0,-4,0,0,-4,0}
};

    static const IndirectHamTerm INDIRECT_TERMS[15] = {
{1,1,1,0,0,0,0,0,0,1,1,0,0,0,0}, {1,2,0,2,0,0,0,0,0,1,1,0,0,0,0}, {1,2,0,0,2,0,0,0,0,1,1,0,0,0,0},
{1,64,0,4,0,0,0,0,0,1,1,0,0,0,0}, {1,64,0,0,4,0,0,0,0,1,1,0,0,0,0}, {1,4,1,2,2,0,0,0,0,1,1,0,0,0,0},
{1,4,0,0,0,2,0,0,0,1,1,0,0,0,0}, {1,4,0,0,0,0,2,0,0,1,1,0,0,0,0}, {1,16,0,0,0,4,0,0,0,1,1,0,0,0,0},
{1,16,0,0,0,0,4,0,0,1,1,0,0,0,0}, {1,8,1,0,0,2,2,0,0,1,1,0,0,0,0}, {1,8,1,2,0,2,0,0,0,1,1,0,0,0,0},
{1,8,1,0,2,2,0,0,0,1,1,0,0,0,0}, {1,8,1,2,0,0,2,0,0,1,1,0,0,0,0}, {1,8,1,0,2,0,2,0,0,1,1,0,0,0,0}
};
}

PlanetaryPeriodicPerturbations::PlanetaryPeriodicPerturbations() {}

const std::vector<DirectHamTerm> PlanetaryPeriodicPerturbations::directSeries(
    DIRECT_TERMS, DIRECT_TERMS + sizeof(DIRECT_TERMS) / sizeof(DirectHamTerm));

const std::vector<IndirectHamTerm> PlanetaryPeriodicPerturbations::indirectSeries(
    INDIRECT_TERMS, INDIRECT_TERMS + sizeof(INDIRECT_TERMS) / sizeof(IndirectHamTerm));

void PlanetaryPeriodicPerturbations::deriv(double s, int j, double& dv, double alpha, double excrit, int ider) const {
    double z1 = 1.0, z2 = 1.0, count = 0.0, term = std::pow(alpha, j);
    int iexp = 0;
    double z = 1.0;
    for (int l = 0; l < j; ++l) z *= (s + l) / (l + 1.0);
    z *= 2.0;

    while (true) {
        double current = 0;
        if (ider == 1) current = z * (static_cast<double>(j) + iexp) * term;
        else if (ider == 2) current = z * (static_cast<double>(j) + iexp) * (static_cast<double>(j) + iexp - 1.0) * term;
        else if (ider == 3) current = z * (static_cast<double>(j) + iexp) * (static_cast<double>(j) + iexp - 1.0) * (static_cast<double>(j) + iexp - 2.0) * term;
        else if (ider == 4) current = z * (static_cast<double>(j) + iexp) * (static_cast<double>(j) + iexp - 1.0) * (static_cast<double>(j) + iexp - 2.0) * (static_cast<double>(j) + iexp - 3.0) * term;
        else if (ider == 5) current = z * (static_cast<double>(j) + iexp) * (static_cast<double>(j) + iexp - 1.0) * (static_cast<double>(j) + iexp - 2.0) * (static_cast<double>(j) + iexp - 3.0) * (static_cast<double>(j) + iexp - 4.0) * term;

        dv += current;
        z1 *= (s + count) / (count + 1.0);
        z2 *= (s + static_cast<double>(j) + count) / (static_cast<double>(j) + 1.0 + count);
        iexp += 2;
        term = z1 * z2 * std::pow(alpha, j + iexp);
        if (std::abs(current) < excrit && iexp > 2) break;
        if (++count > 500) break; 
    }
}

void PlanetaryPeriodicPerturbations::lapco(double a, int np, double excrit, 
                                           std::vector<double>& b, std::vector<double>& b1, 
                                           std::vector<double>& b2, std::vector<double>& b3, 
                                           std::vector<double>& b4, std::vector<double>& b5, 
                                           std::vector<double>& c, std::vector<double>& c1, 
                                           std::vector<double>& c2, std::vector<double>& c3, 
                                           std::vector<double>& e, std::vector<double>& e1) const {
    b.assign(np + 1, 0.0); b1.assign(np + 1, 0.0); b2.assign(np + 1, 0.0); b3.assign(np + 1, 0.0); b4.assign(np + 1, 0.0); b5.assign(np + 1, 0.0);
    c.assign(np + 1, 0.0); c1.assign(np + 1, 0.0); c2.assign(np + 1, 0.0); c3.assign(np + 1, 0.0);
    e.assign(np + 1, 0.0); e1.assign(np + 1, 0.0);

    for (int i = 1; i <= 3; ++i) {
        double s = 0.5 + (i - 1);
        double val = 2.0;
        double aku = 1.0;
        double cj = 0.0;
        while (true) {
            double f = (s + cj) / (cj + 1.0);
            aku *= a * a * f * f;
            val += 2.0 * aku;
            if (2.0 * aku < excrit || ++cj > 500) break;
        }
        if (i == 1) b[0] = val;
        else if (i == 2) c[0] = val;
        else if (i == 3) e[0] = val;
    }

    auto lap = [&](double s, int j, double alpha, double& v) {
        v = 0; double z_val = 1.0;
        for (int l = 0; l < j; ++l) z_val *= (s + l) / (l + 1.0);
        z_val *= 2.0 * std::pow(alpha, j);
        double z1 = 1.0, z2 = 1.0, count = 0.0, term = 1.0;
        int iexp = 2;
        while (true) {
            double current = z_val * term;
            v += current;
            z1 *= (s + count) / (count + 1.0);
            z2 *= (s + static_cast<double>(j) + count) / (static_cast<double>(j) + 1.0 + count);
            term = z1 * z2 * std::pow(alpha, iexp);
            if (std::abs(current) < excrit && iexp > 2) break;
            if (++count > 500) break;
            iexp += 2;
        }
    };

    for (int k = 1; k <= np; ++k) {
        lap(0.5, k, a, b[k]); lap(1.5, k, a, c[k]); lap(2.5, k, a, e[k]);
    }

    for (int k = 0; k <= np; ++k) {
        if (k == 0) {
            auto calc_k0 = [&](double s, double& dv, int ider) {
                dv = 0; double cj = 0, nn = 2, aku = 1;
                while(true) {
                    double f = (s + cj) / (cj + 1.0);
                    aku *= a * a * f * f;
                    double term = 2.0 * aku * nn;
                    if (ider == 2) term *= (nn - 1.0);
                    dv += term;
                    if (std::abs(term) < excrit || ++cj > 500) break;
                    nn += 2;
                }
            };
            calc_k0(0.5, b1[0], 1); calc_k0(1.5, c1[0], 1); calc_k0(2.5, e1[0], 1);
            calc_k0(0.5, b2[0], 2);
        } else {
            deriv(0.5, k, b1[k], a, excrit, 1); deriv(1.5, k, c1[k], a, excrit, 1); deriv(2.5, k, e1[k], a, excrit, 1);
            deriv(0.5, k, b2[k], a, excrit, 2); deriv(0.5, k, b3[k], a, excrit, 3); deriv(0.5, k, b4[k], a, excrit, 4);
            deriv(0.5, k, b5[k], a, excrit, 5); deriv(1.5, k, c2[k], a, excrit, 2); deriv(1.5, k, c3[k], a, excrit, 3);
        }
    }
}

void PlanetaryPeriodicPerturbations::levco(int i, const std::vector<double>& b, 
                                           const std::vector<double>& b1, const std::vector<double>& b2, 
                                           const std::vector<double>& b3, const std::vector<double>& b4, 
                                           const std::vector<double>& c, const std::vector<double>& c1, 
                                           const std::vector<double>& c2, const std::vector<double>& e, 
                                           double a, double pai, std::vector<double>& cl) const {
    cl.assign(381, 0.0);
    int j = std::abs(i), j1 = std::abs(i - 1), j2 = std::abs(i + 1);
    double di = (double)i;

    cl[1] = pai * b[j] / 2.0; cl[2] = pai * (-2.0 * di * di * b[j] + b1[j] + b2[j] / 2.0); cl[3] = cl[2];
    cl[4] = pai * ((-9.0 * di * di + 16.0 * std::pow(di, 4)) * b[j] / 8.0 - di * di * (b1[j] + b2[j]) + b3[j] / 2.0 + b4[j] / 8.0);
    cl[5] = pai * (8.0 * std::pow(di, 4) * b[j] + (2.0 - 8.0 * di * di) * b1[j] + (7.0 - 4.0 * di * di) * b2[j] + 4.0 * b3[j] + b4[j] / 2.0);
    cl[6] = pai * ((-17.0 * di * di + 16.0 * std::pow(di, 4)) * b[j] / 8.0 + 3.0 * (1.0 - di * di) * b1[j] + (9.0 - 2.0 * di * di) * b2[j] / 2.0 + 1.5 * b3[j] + b4[j] / 8.0);
    cl[11] = -a * pai / 4.0 * (c[j1] + c[j2]); cl[12] = a * pai * ((di * di - 0.5) * (c[j1] + c[j2]) - (c1[j1] + c1[j2]) - 0.25 * (c2[j1] + c2[j2]));
    cl[21] = pai * ((2.0 * di + 4.0 * di * di) * b[j] - 2.0 * b1[j] - b2[j]);
}

std::array<double, 6> PlanetaryPeriodicPerturbations::calculateCorrections(
    const KeplerianElements& elements,
    double mjd,
    bool verbose) const {

    std::array<double, 6> corrections = {0,0,0,0,0,0};

    double e_ast = std::max(1e-8, elements.eccentricity);
    double i_ast = elements.inclination;
    double si = std::sin(i_ast);
    double n_ast = elements.mean_motion();

    double L_ast = normalize(elements.mean_anomaly + elements.argument_perihelion + elements.longitude_ascending_node);
    double g_ast = elements.argument_perihelion;
    double h_ast = elements.longitude_ascending_node;

    double dt = (mjd + 2400000.5) - T0_LONGSTOP;
    double dd5 = 0;

    const double MASS_PLANET[9] = {0, MERCURY_MASS_RATIO, VENUS_MASS_RATIO, EARTH_MOON_MASS_RATIO, MARS_MASS_RATIO, JUPITER_MASS_RATIO, SATURN_MASS_RATIO, URANUS_MASS_RATIO, NEPTUNE_MASS_RATIO};

    // Vectors for Laplace coefficients (size sufficiently large for max harmonic)
    const int np_max = 400;
    const double excrit = 1e-10;
    std::vector<double> b, b1, b2, b3, b4, b5, c, c1, c2, c3, e, e1;
    std::vector<double> cl;

    // Loop over perturbing planets (Jupiter=5, Saturn=6, Uranus=7, Neptune=8)
    for (int iplan = 5; iplan <= 8; ++iplan) {
        double a_p = A_PLANET[iplan];

        // Skip if not an outer planet (for main belt asteroids)
        if (elements.semi_major_axis >= a_p) continue;

        double alpha = elements.semi_major_axis / a_p;
        // Use GMS for AU/day units consistency
        double n_p = std::sqrt(constants::GMS / (a_p * a_p * a_p));
        // Potential scaling factor GM/a' (energy per unit mass)
        double energy_scale = constants::GMS / a_p;

        // Compute Laplace coefficients for this alpha
        lapco(alpha, np_max, excrit, b, b1, b2, b3, b4, b5, c, c1, c2, c3, e, e1);

        double l_p = normalize(FAG_PLANET[iplan] + G_PLANET[iplan] * dt);
        double e_p = E_PLANET[iplan];
        double si_p = std::sin(I_PLANET[iplan]);

        int last_i_lev = -1;

        for (const auto& term : directSeries) {
            // Update Leverrier coefficients if harmonic index changes
            if (term.i_lev != last_i_lev) {
                levco(term.i_lev, b, b1, b2, b3, b4, c, c1, c2, e, alpha, PI, cl);
                last_i_lev = term.i_lev;
            }

            double div_val = term.k_p * n_p + term.k_a * n_ast;
            // Avoid resonance singularities (small divisors)
            // For analytical non-resonant theory, we must skip resonant terms
            if (std::abs(div_val) < 1e-4) continue;

             // Calculate term amplitude factor
            double efac = (term.e_pow == 0) ? 1.0 : std::pow(e_ast, term.e_pow);
            double epfac = (term.ep_pow == 0) ? 1.0 : std::pow(e_p, term.ep_pow);
            double sifac = (term.s_pow == 0) ? 1.0 : std::pow(si, term.s_pow);
            double sipfac = (term.sp_pow == 0) ? 1.0 : std::pow(si_p, term.sp_pow);

            // Factor from term integer coeff and divisor
            // Note: mul is the INDEX into cl array. div is the DIVISOR.
            // cl[term.mul] is the Leverrier coefficient.
            // MASS_PLANET[iplan] scales by perturbing mass ratio.
            // energy_scale provides physical units (L^2/T^2).
            double coeff_val = cl[term.mul];
            double term_amp = (1.0 / (double)term.div) * efac * epfac * sifac * sipfac * coeff_val * MASS_PLANET[iplan] * energy_scale;

            // Argument of the term
            double arg = term.k_p * l_p + term.k_a * L_ast +
                         term.m1 * elements.mean_anomaly +
                         term.m2 * g_ast +
                         term.m3 * h_ast;

            // Semi-major axis correction: Delta a = (2 * k_a / (n_a^2 * a_a)) * R_term / (freq) * cos(arg)
            // Note: R_term already contains factor GM/a_p.
            // In Delaunay vars: da/dt = 2/na * dR/dM.
            // Delta a = 2/(n*a) * sum (ka * R_k / div_val * cos(arg))
            double a_ast = elements.semi_major_axis;
            if (term.k_a != 0) {
                 if (std::abs(n_ast * a_ast) < 1e-12) continue;
                 double pre_factor = (2.0 / (n_ast * a_ast));
                 double resonance_factor = (term_amp * term.k_a / div_val);
                 double cos_arg = std::cos(arg);
                 double contrib = pre_factor * resonance_factor * cos_arg;

                 dd5 += contrib;
            }
        }
    }

    // Assign to delta_a
    corrections[0] = dd5;
    return corrections;
}

} // namespace astdyn::propagation
